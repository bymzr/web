console.log('mock');
import Mock from 'mockjs'
const Random = Mock.Random;
Random.extend({
    goodname(){
        return this.pick(['小米','iphone','beats','bo','huawei']);
    }
})
Mock.mock('goodList','get',(data)=>{
    let goodList=[];
    for(let i=0;i<5;i++){
            goodList.push({
                goodname:Random.goodname(),
                price:Random.natural(1,800)
            });

           return goodList; 
    }
})

