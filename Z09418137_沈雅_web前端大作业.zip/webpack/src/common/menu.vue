<template>

<el-menu  class="el-menu-demo" mode="horizontal" >
  
  <el-menu-item index="1"><router-link to='/'>首页</router-link></el-menu-item>

    
    <el-menu-item index="2"><router-link to='list'>全部商品</router-link></el-menu-item>

  
  <el-menu-item index="4"><a href="https://www.ele.me" target="_blank">订单管理</a></el-menu-item>

  <div class="input">
  <el-input placeholder="请输入内容" class="input-with-select" v-model="search">
    <el-button slot="append" icon="el-icon-search" @click="searchClick"></el-button>
  </el-input>
  </div> 
  </el-menu>
  


</template>
<script>
  export default {
      name:'Menu',
  data() {
    return {
      search: "" // 搜索条件
    }
    },
    methods:{
    // 点击搜索按钮
    searchClick() {
      if (this.search != "") {
        // 跳转到全部商品页面,并传递搜索条件
        this.$router.push({ path: "/list", query: { search: this.search } });
        this.search = "";
      }
    }
    }
  }
</script>
<style>
.menu{
  background: rgb(247, 245, 245);
  width: 100%;
  height: 60px;

}
.pot{
  margin:22px ;
 
}
.input{
  
  margin-left: 300px;
position: absolute;
z-index: 10;
}
.el-select .el-input {
     
    height: 40px;
    position: relative;
    
  }
  .el-input{
    margin: 10px 200px;
    
    width: 500px;
    z-index: 10;
  }
  .input-with-select .el-input-group__prepend {
    background-color: #fff;
    width: 50%;
  }
</style>