<template>
<div class="container" >
 
  <div >
    <img class="img1" src="static/images/7.png"/>
  </div>
  <div class="font1" width="200px">
   <router-link to="/" class="name"> 岐妙商城</router-link>
  </div>
     
  
            <div class="header">
              <div class="header-menu">
                <router-link to="/cart" class="header-menu-cart">
                        购物车 </router-link>
                        <span v-if="cartList.length" class="header-menu-cart">{{cartList.length}}</span>
                </div>
                <div class="header-menu" v-if="loginStatus">
                <el-row class="block-col-2">
                
                  <el-dropdown>
                    <span class="el-dropdown-link">
                        <router-link to="/" class="header-menu-cart">{{user}}</router-link></span>
                  
                   <el-dropdown-menu slot="dropdown" v-if="loginStatus">
                     <el-dropdown-item icon="el-dropdown-item">
                        <router-link to="checkout">我的订单</router-link>
                      </el-dropdown-item>
                      <el-dropdown-item icon="el-dropdown-item">
                        <router-link to="/">账号资料</router-link>
                      </el-dropdown-item>
                      
                      <el-dropdown-item icon="el-dropdown-item">
                        <router-link to="/">售后服务</router-link>
                     </el-dropdown-item>
                     <el-dropdown-item icon="el-dropdown-item">
                        <router-link to="/">我的优惠</router-link>
                     </el-dropdown-item>
            </el-dropdown-menu>
            </el-dropdown>
          </el-row>           
                  
                </div>
                <div class="header-menu" v-if="loginStatus">
                    <router-link to="/login/logout"
                                 class="header-menu-cart">
                        退出登录
                    </router-link>
                </div>
                <div class="header-menu" v-if="!loginStatus">
                    <router-link to="/login/logout"
                                 class="header-menu-cart">
                        登录
                    </router-link>
                </div>
                <div class="header-menu">
                    <router-link to="list"
                                 class="header-menu-cart">
                        全部商品
                    </router-link>
                </div>
            </div>
          
            
          
   
</div>
</template>
<script>
import {mapState} from 'vuex'
  export default{
    name: 'Header',
    data() {
    return {
      input: '',
      select: '',
      user: this.$store.getters.user,
      loginStatus:this.$store.getters.loginStatus
    }
  },computed: {
            cartList(){
                return this.$store.state.cartList;
            },
            number(){
            return this.$store.getters.goodsNumber
      }
            }
  
  }
</script>
<style >
.container{
  position:absolute;
  width: 100%;
}

.img1{
  float:left;
  position: relative;
  height: 50px;
}
.font1
{ 
  margin: 10px 30px;
  float:left;
  color: #fff;
  height: 50px;
  font-size: 25px;
  
}

  
.header-menu{
    margin-top:15px;
    float: right;
    margin-right: 32px;
    z-index: 10;
    
}
.header-menu-cart{
    color: #fff;
    text-decoration: none;
}


.header-menu-cart span{
    display: inline-block;
    width: 16px;
    height: 16px;
    line-height: 16px;
    text-align: center;
    border-radius: 50%;
    background: #ff5500;
    color: #fff;
    font-size: 12px;
}
.header-menu-cart span{
    display: inline-block;
    width: 16px;
    height: 16px;
    line-height: 16px;
    text-align: center;
    border-radius: 50%;
    background: #ff5500;
    color: #fff;
    font-size: 12px;
} 
 .el-dropdown-link {
    cursor: pointer;
    color: #409EFF;
  }
  .el-icon-arrow-down {
    font-size: 12px;
  }
  .demonstration {
    display: block;
    color: #8492a6;
    font-size: 14px;
    margin-bottom: 20px;
  }
.name{
  text-decoration: none;
  color: #fff;
}
.name:hover{
  color:#350544;
}
.el-dropdown-link{
  text-decoration: none;
}
</style>

