<template>
<div class="container">
<el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="handleSelect">
  <el-submenu index="2">
	  
    <template slot="title"><span>全部分类</span></template>
    <el-menu-item index="2-1">潮流女装</el-menu-item>
    <el-menu-item index="2-2">品牌男装</el-menu-item>
    <el-menu-item index="2-3">家用电器</el-menu-item>
    <el-submenu index="2-4">
      <template slot="title">手机数码</template>
      <el-menu-item index="2-4-1">耳机</el-menu-item>
      <el-menu-item index="2-4-2">数据线</el-menu-item>
      <el-menu-item index="2-4-3">储存卡</el-menu-item>
    </el-submenu>
  </el-submenu>
  
</el-menu>
</div>
</template>
<script>
  export default {
    data() {
      return {
        activeIndex: '1',
       
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>
<style scoped>
.container{
	position: relative;
	z-index: 21;
	width: 200px;
}
</style>