<template>
<div class="footer">

<span ><a href="#">合作伙伴</a> &nbsp;  <a href="#">联系我们</a>&emsp;Copyright ©2020 闭眼孟中人 版权所有</span>
      
     
  </div>
</template>


<script>
  export default{
    name:'Footer'
  }
</script>
<style >
.footer {
  position: fixed;
   width: 100%;
    color: blueviolet;
    height: 100px;
    text-align: center;
    padding: 10px;
  }

 
 a{
    text-decoration: none;
    color: blueviolet;
    
  
  } 
  a:hover{
    color: blue;
  }   
</style>
