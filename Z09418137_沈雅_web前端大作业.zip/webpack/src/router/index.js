import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/views/Index'
import Home from '@/views/Home/home'
import Login from '@/views/Login/login'
import List from '@/views/list'
import Goods from '@/components/goods'
Vue.use(Router)
export default new Router({
   routes:[
    {
      path: '/',
      component: Index,
      name: 'index',
      redirect: '/home', 
      children: [
        {path: 'home', component: Home,meta:{title: '主页' }}, 
        { path: 'list',component:List,meta: {title: '全部分类'}},
        { path: 'goods',component:Goods},
        { path: 'cart',meta: {title: '购物车',requireAuth:true}, component: (resolve) => require(['@/views/cart.vue'], resolve)} ,
        {path: 'product/:id',meta: {title: '商品详情'},component: (resolve) => require(['@/components/product.vue'], resolve)},
        {path:'checkout',meta: {title: '支付'},component: (resolve) => require(['@/views/checkout.vue'], resolve)},
        {path:'test',meta: {title: ''},component: (resolve) => require(['@/views/test.vue'], resolve)}
      ]
    },
    {path: '/home', name: 'home',meta: {title: '主页'}, component: Home},
    {path: '/login', name: 'login',meta: {title: '登录注册'}, component: Login},
    { path: '/product/:id',meta: {title: '商品详情'},component: (resolve) => require(['@/components/product.vue'], resolve)}
    ,
    {path: '/login/:loginStatus',meta: { title: '登录注册'},component: (resolve) => require(['@/views/Login/login.vue'], resolve)},
    {path: '*',redirect: '/home/home'}
  ]
})
