<template>
<div>
    <div class="title">
    热销产品
    </div>
    <div class="product" >
         <router-link :to="'product/' +item.id"  v-for=" (item,index) in product_data " :key="index" class="product-main">
            
                    <img :src="item.image">
                    <h1 class="product-name" >{{item.name}}</h1>
                    <h1 class="product-cost" >￥ {{item.cost}}</h1>
                    <div class="product-add-cart" @click.prevent="handleAddCart">加入购物车</div>             
        </router-link>
    </div>
 </div>
</template>

<script>
    import product_data from '../product.js';

    export default {
        data(){
       return{
           product_data:product_data
       }},
        methods: {
            getProduct(){
                setTimeout( () => {
                    this.product = product_data.find(item => item.id === this.id);
                }, 500);
            },
            handleAddCart(){
                this.$store.commit('addCart', this.id)
            }
        },
        mounted(){
            //初始化数据
            this.getProduct()
        }
    }
</script>
<!-- scoped属性表示只对当前组件有效，不影响其他组件 -->
<style scoped>
.title {
     
      position: relative;
      height: 60px;
      padding: 0 10px 0 24px;
      border-bottom: 1px solid #d4d4d4;
      border-radius: 8px 8px 0 0;
      box-shadow: rgba(0, 0, 0, .06) 0 1px 7px;
      background: #f3f3f3;
      background: -webkit-linear-gradient(#fbfbfb, #ececec);
      background: linear-gradient(#fbfbfb, #ececec);
      line-height: 60px;
      font-size: 18px;
      color: #333;
      display: flex;
      justify-content: space-between;
      align-items: center;
     
      }
   .product{
        padding:20px 0 0 55px;
        background: #fff;
        border: 1px solid #dddee1;
        border-radius: 10px;
        overflow: hidden;
    }
    .product-main{
        width: 27%;
        display: block;
        float: left;
        margin: 16px;
        padding: 16px;
        border: 1px solid #dddee1;
        border-radius: 6px;
        overflow: hidden;
        background: #fff;
        text-align: center;
        position: relative;
    }
    .product-image img{
       width: 100%;
    }

    .product-cost{
        color: #f2352e;

    }
 .product-add-cart{
        display: none;
        padding: 4px 8px;
        background: #2d8cf0;
        color: #fff;
        font-size: 12px;
        border-radius: 3px;
        cursor: pointer;
        position: absolute;
        top: 5px;
        right: 5px;
    }
    .product-main:hover .product-add-cart{
        display: inline-block;
    }

</style>