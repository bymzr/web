// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/index'
import store from './store/index'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
import './mock/mock.js'
Vue.prototype.$http = axios
Vue.config.productionTip = false
Vue.prototype.$store = store
Vue.use(ElementUI)
/* eslint-disable no-new */
//路由配置

//跳转前设置title
router.beforeEach((to, from, next) => {
  window.document.title = to.meta.title;
  if(to.meta.requireAuth){
    if(localStorage.getItem('username')){
      next();
    }else{
      next({
        path:'/login'
      })
    }
  }else{
    next();
  }
});
//跳转后设置scroll为原点
router.afterEach((to, from, next) => {
  window.scrollTo(0, 0);
});


new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)

})
