import Vue from 'vue';
import VueRouter from 'vue-router';
import Vuex from 'vuex';
import router from '../router/index'
import product_data from '../product';
import axios from 'axios';
Vue.use(VueRouter);

Vue.use(Vuex);
export default new Vuex.Store({
 
    state: {
        goodList:[],
        //商品列表信息
        productList: [],
        //购物车数据，数组形式，数据元素为对象（商品id，购买数量count）
        cartList: [],
        //当前用户账号
        username: window.localStorage.getItem('username'),
        //登录状态
        loginStatus: !!window.localStorage.getItem('loginStatus'),
    },
    getters: { 
        
        user:state=>{
            return state.username
        },
        goodsNumber:state=>{
            return state.cartList.length
        },
        loginStatus:state=>{
            return state.loginStatus
        },
        getIsAllCheck:state=> {
            // 判断是否全选
            let isAllCheck = true;
            for (let i = 0; i < state.cartList.length; i++) {
              const temp = state.cartList[i];
              // 只要有一个商品没有勾选立即return false;
              if (!temp.check) {
                isAllCheck = false;
                return isAllCheck;
              }
            }
            return isAllCheck;
          }
    },
    //mutations只能以同步方式
    mutations: {
       setGoodList(state,goodList){
           state.goodList = goodList;
       },
        //添加商品列表
        setProductList(state, data){
            state.productList = data;
        },
        checkAll(state, data) {
            // 点击全选按钮，更改每个商品的勾选状态
            for (let i = 0; i < state.cartList.length; i++) {
              state.cartList[i].check = data;
            }
          },
        //添加购物车
        addCart(state, id){
            
            const isAdded = state.cartList.find(item => item.id === id);
          
            
            //如果不存在设置购物车为1，存在count++
            if(isAdded){
                isAdded.count++;
            }else{
                state.cartList.push({
                    id: id,
                    count: 1
                })
            }
        
    },
        updateCart(state, payload) {
            // 更新购物车
            // 可更新商品数量和是否勾选
            // 用于购物车点击勾选及加减商品数量
            if (payload.prop == "num") {
              // 判断效果的商品数量是否大于限购数量或小于1
              if (state.cartList[payload.key].maxNum < payload.val) {
                return;
              }
              if (payload.val < 1) {
                return;
              }
            }
            // 根据商品在购物车的数组的索引和属性更改
            state.cartList[payload.key][payload.prop] = payload.val;
          },
        //修改购物车商品数量
        editCartCount(state, payload){
            const product = state.cartList.find(item => item.id === payload.id);
            product.count += payload.count;
        },
        //删除购物车商品
        deleteCart(state, id){
            const index = state.cartList.findIndex(item => item.id === id);
            state.cartList.splice(index, 1)
        },
        //清空购物车
        emptyCart(state){
            state.cartList = [];
        },
        getUser(state, username){
            console.log('username',username)
            state.username = username;
        },
        getLoginStatus(state, flag){
            state.loginStatus = flag;
        }
    },
    actions: {
        loadGoodList({commit}){
            axios.get('goodList').then(respone=>{
                commit('setGoodList',respone.data);
            })
            .catch(error=>{
                console.log(error);})
        },
        //异步请求商品列表，暂且使用setTimeout
        getProductList(context){ 
            setTimeout(() => {
                context.commit('setProductList', product_data)
            }, 500);
        },
        updateCart({ commit }, payload) {
            commit('updateCart', payload);
          },
        checkAll({ commit }, data) {
            commit('checkAll', data);
          },
        //购买
        buy(context){
            //生产环境使用ajax请求服务端响应后再清空购物车
            return new Promise(resolve => {
                setTimeout(() => {
                    context.commit('emptyCart');
                    resolve();
                }, 500);
            });
        },
    }
  }
)