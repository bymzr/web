<template>
<div>
    <div class="cart-header-main">
                <div class="cart-info">商品名字</div>
                <div class="cart-price">单价</div>
                
        </div>
         <div class="cart-content">
            <!-- 列表显示购物清单 -->
            <div class="cart-content-main" v-for="(good,index) in goodList" :key="index">
                <div class="cart-info" >
                    
                    {{good.goodname}}
                </div>
                <div class="cart-price">
                    ￥ {{good.price}}
                </div>
              
                
            </div>
            
        </div>
   
    </div>
</template>

<script>
  export default{  
      computed:{
          goodList(){
              return this.$store.state.goodList;
          }
      },
        mounted() {
          
                this.$store.dispatch('loadGoodList');
           
           
        }
}  
    
</script>

