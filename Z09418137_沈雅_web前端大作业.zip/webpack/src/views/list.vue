<template>
<div class="container" >
    <div class="header">
      <Header></Header>      
    </div>
    <div class="product" >
        <router-link :to="'product/' +item.id"  v-for=" (item,index) in product_data " :key="index" class="product-main">
            
                    <img :src="item.image">
                    <h1 class="product-name" >{{item.name}}</h1>
                    <h1 class="product-cost" >￥ {{item.cost}}</h1>
                    <div class="product-add-cart" @click.prevent="handleAddCart">加入购物车</div>
                
            
        </router-link>
    </div>
</div>
</template>

<script>
    import product_data from '../product.js';
    import Header from '../common/header'
 
    export default {
        components:{
            Header
        },

        data(){
       return{
           product_data:product_data
       }},
       
        methods: {
            getProduct(){
                setTimeout( () => {
                    this.product = product_data.find(item => item.id === this.id);
                }, 500);
            },
           handleAddCart(){
                this.$store.commit('addCart', this.id);
            }
        },
        mounted(){
            //初始化数据
            this.getProduct()
        }
    }
</script>
<!-- scoped属性表示只对当前组件有效，不影响其他组件 -->
<style scoped>

.header {
    background-color: black;
    height: 65px;
  } 

 .product{
        
        padding: 32px;
        background: #fff;
        border: 1px solid #dddee1;
        border-radius: 10px;
        overflow: hidden;
    }
    .product-main{
        width: 25%;
        display: block;
        float: left;
        margin: 16px;
        padding: 16px;
        border: 1px solid #dddee1;
        border-radius: 6px;
        overflow: hidden;
        background: #fff;
        text-align: center;
        position: relative;
        text-decoration: none;
    }
    .product-image img{
       width: 100%;
    }


    .product-cost{
        color: #f2352e;

    }
 .product-add-cart{
        display: none;
        padding: 4px 8px;
        background: #2d8cf0;
        color: #fff;
        font-size: 12px;
        border-radius: 3px;
        cursor: pointer;
        position: absolute;
        top: 5px;
        right: 5px;
    }
    .product-main:hover .product-add-cart{
        display: inline-block;
    }

</style>