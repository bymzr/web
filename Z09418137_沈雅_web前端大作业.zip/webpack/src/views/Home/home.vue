<template>
<el-container class="home-container">
  <el-header>
      <Header/>      
  </el-header>
  <div><Menu/></div>
      <el-main> 
        <div class="main-container">
          <div width="200px" class="aside">
              <Aside></Aside>
          </div>   
          <div class="banner">
            <el-carousel indicator-position="outside" class="carousel" type="card" :height="bannerH+'px'">
              <el-carousel-item v-for="(img,index) in imgList" :key="index" >    
                <img v-bind:src="img.url"> 
              </el-carousel-item>
            </el-carousel>
            </div>  
          </div>
          <div class="goods">
             <Goods></Goods> 
          </div>
      </el-main>      
      <el-footer  style="height:100px" >
      <Footer/>
     </el-footer> 
      <router-view></router-view>
</el-container>

</template>
<script>
import Header from '../../common/header'
import Footer from '../../common/footer'
import Menu from '../../common/menu'
import Aside from '../../common/aside'
import Goods from '../../components/goods'
import List from '../list'
import 'element-ui/lib/theme-chalk/index.css'
import ElementUI from 'element-ui'
export default {
  components: { 
      Header,
      Menu,
      Aside,
      Footer,
      Goods,
      List
    },
    data(){
    return{ 
      imgList:[
        {url:require('../../assets/6.jpg')},
        {url:require('../../assets/5.jpg')},
        {url:require('../../assets/4.jpg')},
        {url:require('../../assets/8.png')}
      ],
      bannerH :270,
    }
  }
}
</script>
<style>
.home-container{
    position: fixed;
    height: 100%;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    
}
.el-header {
    background-color: black;
 
  } 


  .el-main {
    background-color: rgb(255, 255, 255);

  }
  .main-container{  
    width: 100%;
   height: 370px;
  }
  .banner{
      cursor: pointer;
      perspective: 3000px;
      position: relative;
      z-index: 19;
      padding-left: 230px;   
  }
  .el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
.el-carousel__item img{
  width: 100%;
  height: 100%;
}
.goods{
  width: 100%;
}
.aside{
  float: left;
  z-index: 20;
 
}
</style>